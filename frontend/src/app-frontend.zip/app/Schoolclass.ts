export class Schoolclass{
  constructor(public id:string,
              public room: string) {
  }
}
