import {Component, OnInit} from '@angular/core';
import {Unit} from "./Unit";
import {HttpClientService} from "./http-client.service";
import {Schoolclass} from "./Schoolclass";
import {Teacher} from "./Teacher";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit{
  title = 'frontend-stundenplan';

  days:Array<string> = ["Mo", "Di", "Mi", "Do", "Fr"];
  hours: Array<number> = [1, 2, 3, 4, 5];
  schoolclasses:Array<Schoolclass> = [];
  currentSchoolclass: Schoolclass | undefined;
  teachers:Teacher[] = [];
  units:Unit[] = [];
  // @ts-ignore
  ws: WebSocket;
  wsUri: string = "ws://localhost:3000"

  constructor(private em: HttpClientService) {}


  ngOnInit(): void {
    this.loadAll();
    this.doConnect();
  }

  loadAll(){
    this.em.getAllTeachers().subscribe((data)=>{
      this.teachers = data;
    });
    this.em.getAllSchoolclasses().subscribe((data)=>{
      this.schoolclasses = data;
      this.getNewTimetableString(this.currentSchoolclass != undefined ? this.currentSchoolclass.id: this.schoolclasses[0].id)
    });
  }

  public getNewTimetable(event: Event):void{
    // @ts-ignore
    this.getNewTimetableString(event.target.value);
  }

  public findSchoolClass(id: string): Schoolclass | undefined{
    for(let s of this.schoolclasses){
      if(s.id == id){
        return s;
      }
    }
    return undefined;
  }

  public findTeacher(id: number): Teacher | undefined{
    for(let t of this.teachers){
      if(t.id == id){
        return t;
      }
    }
    return undefined;
  }

  public getNewTimetableString(event: string):void{
    // @ts-ignore
    this.em.getUnitsOfClass(event).subscribe((data:Unit[])=>{
      this.units = data;

      if(this.currentSchoolclass)
        this.currentSchoolclass.id = event;
    })
  }

  public getUnit(i:number, j:number):Unit{
    //@ts-ignore
    let displayUnit: Unit;
    for(let unit of this.units){
      if(unit.unit == i && unit.day == j + 1){
        displayUnit = unit;
      }
    }
    // @ts-ignore
    if(displayUnit == undefined){

      // @ts-ignore
      displayUnit = new Unit(0, j + 1, i, "frei", 0, null, false);
      this.units.push(displayUnit);
    }
    return displayUnit;
  }

  public save():void{
    for(let unit of this.units){
      if(unit.hasChanged){
        if(unit.schoolclassID == null){
          unit.schoolclassID = this.currentSchoolclass != null ? this.currentSchoolclass.id : this.schoolclasses[0].id;
        }
        // @ts-ignore
        this.em.saveUnit(unit).subscribe();
      }
    }
    this.ws.send("something has changed");
  }

  doConnect(): void{
    this.ws = new WebSocket(this.wsUri);
    this.ws.onopen = (evt) => {
      console.log('Websocket connected');
    };

    this.ws.onmessage = (evt) => {
        this.loadAll();
    };

    this.ws.onerror = (evt) => {
      console.error('Websocket error');
    };

    this.ws.onclose = (evt) => console.log('Websocket closed');
  }
}
